(function () {
    'use strict';

    var beautifier = require('../../../../html/lib/beautify.js');

    var countSpan = document.getElementById("idStepCount");
    var copyText = document.getElementsByClassName("copyTextStatus");
    const prefix = "describe('Title of the script', function() {\n";
    const suffix = "});"
    const itTagPrefix = "it('Step', async function() {";
    const itTagSuffix = "});"
    var steps = [];
    var count = 0;

    const actionsArray = ["stepsBasket", "downloadScript", "copyButton", "toggleTreeMode"];
    const executeClickActions = {
        stepsBasket: actionAddStepClick,
        downloadScript: actionDownloadScriptClick,
        copyButton: copyActionClick,
        toggleTreeMode: toggleActionClick
    };

    actionsArray.forEach((actionId) => {
        var action = document.getElementById(actionId);
        if (action) {
            action.addEventListener("click", executeClickActions[actionId]);
        }
    });

    function toggleActionClick() {
        try {
            var splitter = document.getElementById("tree-splitter-splitter");
            var orientation = splitter.getAttribute("orientation");
            splitter.setAttribute("orientation", orientation === "vertical" ? "horizontal" : "vertical");
        } catch (e) {

        }
    }

    function copyActionClick() {
        let edt = getEditorControl();
        if(!edt){return;}
        // Get value of editor
        edt.focus();
        edt.execCommand("selectAll");
        copyText[0].classList.toggle("copyText");
        setTimeout(() => {
            edt.focus();
            document.execCommand("copy");
        }, 300);
        setTimeout(() => {
            copyText[0].classList.toggle("copyText");
        }, 1000);

    }

    function actionAddStepClick() {
        let edt = getEditorControl();
        if(!edt){return;}

        var text = edt.getValue();
        if (isValidText(text)) {
            addToQueue(text);
        }

    }

    function actionDownloadScriptClick() {
        if (steps.length > 0) {
            saveDynamicDataToFile();
        }
    }

    function addToQueue(text) {
        steps.push(text);
        count++;
        countSpan.innerHTML = count;
    }

    function saveDynamicDataToFile() {
        var userInput = getFormattedText();
        userInput = beautyfyCode(userInput);
        download(userInput, "specs.js", "text/plain");
    }

    function download(data, filename, type) {
        var file = new Blob([data], { type: type });
        var a = document.createElement("a"),
            url = URL.createObjectURL(file);
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(function () {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 0);
    }

    function getFormattedText() {
        var output = prefix;
        steps.forEach(function (step) {
            output += itTagPrefix ;
            output += step;
            output += itTagSuffix;
        })
        output += suffix ;
        return output;
    }

    function isValidText(text) {
        if (text === undefined || text === null || text.length < 1 || text.indexOf("No valid selector could be generated") > -1) {
            return false;
        }
        return true;
    }

    function getEditorControl(){
        const edt = qmateEditor;
        let edtDom;
        if (!edt) {
            edtDom = document.querySelector('.CodeMirror');
            if (edtDom && edtDom.CodeMirror) {
                edt = edtDom.CodeMirror;
            }
        }
        return edt;
    }

    function beautyfyCode(code) {
        let jsBeautifyExec = beautifier.js_beautify;
        return jsBeautifyExec(code);
    }

})();