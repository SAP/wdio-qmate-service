# Qmate Spotlight
Based on [UI5 Inspector](https://github.com/SAP/ui5-inspector) chrome plugin, it generates Qmate UI5 and non-UI5 selectors for easy test step creation. 
It consist of 2 parts:

**1.** UI5 based Spotlight - Generates UI5 based selectors

**2.** Non-UI5 Spotlight - Generates standard CSS, XPath selectors  

## In which Web Application can Qmate Spotlight be used?
Can be used in any html based application. We tested it with the following technologies:

**1.** UI5 based Application (UI5 Smart Templates, Free style applications).

**2.** Non-UI5 based Application (Web-Dynpros, HTML GUI, Web-Dynpros CRM, Ariba, Success Factors and further HTML based Applications like github, google, youtube etc.).

## Is qmate spotlight a Record-and-Replay tool?
No. We are not providing you with a "record-and-replay" tool. That's the reason we call it Spotlight. We believe in agile testing and automation, behavioral-driven development, reusability, and we believe that you need to write and code your own UI/E2E tests as early as possible and as part of the development process. 

## Installation

1. Clone the repository to your local system.
2. Open the Chrome browser.
3. Go to "Extensions" (chrome://extensions/).
4. Make sure you enabled the "Developer Mode".
5. Drag and drop the **"ChromeExtension"** folder in the chrome extensions area.


## Usage

### UI5 Spotlight
1. Navigate to a UI5 based website
2. Open the developer tools
3. Go to "UI5" tab
4. Hover over the element you want to record

![ui5-qmate-spotlight](./pics/ui5.PNG)

5. Right click, select "UI5 Inspect" option, in the UI tab the element will be selected. Alternatively you can choose the element in the virtual dom representation directly.
6. Select one of the provided actions in the selection menu (Click, Enter value, Clear). Default is "No Action".
7. Once clicking the desired option, the generated code can be copied, adjusted/extended and re-runned if desired.
8. Every time you re-run the generated selectors, the founded element will be highlighted in your screen. 

### Non-UI5 Spotlight
1. Navigate to a any html-based website
2. Open the developer tools
3. Go to "Elements" tab
4. Next to the Elements DOM View, there is the DOM details view (Styles, Event Listeners, Properties), there you will find a new tab called "Qmate Non-UI5 Spotlight". If you don't see it, just click in the double arrow symbol (>>) and you will see it there.
5. Click on "Qmate Non-UI5 Spotlight"

![nonUI5-qmate-spotlight](./pics/nonUI5.PNG)

6. Click on the element in the "Elements panel" to generate the selector. Alternatively on the "selection element icon" in the upper part of the Dev-tools select the element directly in the screen.
7. As default the first "Selector Alternative" will be selected. The selector alternatives are sorted based on length and not robustness or selector efficiency. Remember you have to use your own brain to figure the best possible solution for you. 
7. Select one of the provided actions in the selection menu (Click, Enter value, Clear). Default is "No Action".
8. Once clicking the desired option, the generated code can be copied, adjusted/extended and re-runned if desired.
9. Every time you re-run the generated selectors, the founded element will be highlighted in your screen. 


## Features

**1.** Provides robust selectors for any html-based application.

**2.** Generates Qmate selectors based on [Qmate Reuse API](https://github.tools.sap/sProcurement/wdio-qmate-service/blob/main/reuse/doc.md).

**3.** Provides the possibility to test the selector directly in browser.

**4.** Provides the possibility to adjust, extend and retry the selector directly in browser.

**5.** Provides a text editor with support for undo, redo, copy, paste and so on.

**6.** Provides information on how many elements where found alltogether (in case that the selector finds more elements).

**7.** Provides the possibility to execute an action (currently supports click, fill and clear).

**8.** For non-ui5 selector generation, it automatically scans the page and generates the iframe qmate selectors out-of-the-box for you.

**9.** You can copy an existing selector from an existing script and try it inside the browser, by copying the selector and replace the one in the spotlight. Caution: Only the selector and method context can be changed, not the whole code including the name of the selector or change the name of the method. We do not use eval because of the content policy, we do  string parsing so be cautious.

**10.** You can use UI5 and Non-UI5 Spotlight interchangably and supplementary. You can use simultaneously UI5 and Non-UI5 Spotlight in a UI5 application, but in non-ui5 apps you can only use the Non-UI5 Spotlight.


### Contribution
If you like to extend it for you needs, you can do that by:

**1.** Clone the repository to your local machine

**2.** Adjust the code

**3.** Edit **manifest.json** and increase the version  

**4.** Generate new version of extension **ChromeExtension** folder by executing **npm install** in the root folder

**5.** Drag and drop **ChromeExtension** folder in your Chrome extension page (as described in the above chapter**Installation**) for testing

**6.** Commit and open a PR

### Update Qmate Spotlight with new UI5-Inspector changes

To pull the later ui-inspector changes clone the Qmate Spotlight and execute the following commands:

```javascript

git remote add upstream https://github.com/SAP/ui5-inspector
git fetch upstream
git merge upstream/master

```
Fix the conflict push changes into a PR.


### FAQ

### Recording - For a more guided introduction please check out the recording below
[Recording early adopters](https://web.microsoftstream.com/video/736a68e0-7f3e-4aa6-9ac3-a770ca7b2e44)

#### How can I adjust content of the generated step?
The following rules have to be considered when you are planning to adjust/extend the generated qmate step:

***-*** Change the selector content, with your own selector is possible. Just swap the content of the selector without renaming it. See

```javascript
const selector = {
    "elementProperties": {
        "viewName": "sap.ui.demo.cart.view.Home",
        "metadata": "sap.m.StandardListItem",
        "text": "My own selector"
    }
};
await ui5.element.getDisplayed(selector);
```

***-*** Dont rename the variables generated by the Qmate Spotlight. Example wrong:

```javascript
const myOwnSelector = {
    "elementProperties": {
        "viewName": "sap.ui.demo.cart.view.Home",
        "metadata": "sap.m.StandardListItem"
    }
};
await ui5.element.getDisplayed(myOwnSelector);
```

***-*** Dont use Qmate reuse methods not listed in the Qmate Spotlight. Example wrong:


```javascript
const selector = {
    "elementProperties": {
        "viewName": "sap.ui.demo.cart.view.Home",
        "metadata": "sap.m.StandardListItem"
    }
};
await ui5.element.getValue(selector);
```
Although the Qmate "getValue" reuse is part of our official API, is not part of the Qmate Spotlight yet. More reuse methods will be extend in the near future.

***-*** Use another index value is possible and easy to be done. Example:


```javascript
const selector = {
    "elementProperties": {
        "viewName": "sap.ui.demo.cart.view.Home",
        "metadata": "sap.m.StandardListItem"
    }
};
//Include a new variable and add it to the method
const index = 1;
await ui5.element.getDisplayed(selector, index);
```
The sum of all element can be seen in the upper part of the Qmate Spotlight "Total number of elements found (without index):"

***-*** Use another value to enter is possible and easy to be done. Example:


```javascript
const selector = {
    "elementProperties": {
        "viewName": "sap.ui.demo.cart.view.Home",
        "metadata": "sap.m.StandardListItem"
    }
};
//Replace dummy myValue with your own value
const valueToEnter = "myOwnChangedValue";
await ui5.userInteraction.clearAndFill(selector, valueToEnter);

```


#### How can I test a selector from my existing Qmate test?
Copy your own selector from your spec file and override the one generated from the Spotlight. See example in the previous question.

#### Which Qmate version is supported by Spotlight?
There are 2 parts to the answer:

1. From selector generation perspective:

   ***-*** For non-nested selector generation from version 3.0.0

   ***-*** For nested selector generation from version 4.1.0

   ***-*** For Non-UI5 CSS selectors you can use from version 4.0.0

   ***-*** For Non-UI5 XPAth selectors you can use from version 4.1.5

2. From action perspective:

   ***-*** For all simple UI5 actions (without -Retry in the end) from version 3.0.0

   ***-*** For all UI5 actions including "Retry" from version 4.1.0

To be able to use all the actions and selectors you have to use at **least version 4.1.5**.

#### Found more than 1 element, why the Qmate spotlight didnt failed?
Because all methods described in the [Qmate Reuse API](https://github.tools.sap/sProcurement/wdio-qmate-service/blob/main/reuse/doc.md) are using as default index 0. So the first element will be selected. Make sure this is what you want. If not, you can change the index anytime you like. Here is an example:

```javascript
const selector = {
    "elementProperties": {
        "viewName": "sap.ui.demo.cart.view.Home",
        "metadata": "sap.m.StandardListItem"
    }
};
await ui5.element.getDisplayed(selector);
```
The above generated step is finding 16 elements. It can be seen above the editor: ***Total number of elements found (without index):16***
If you want you can add the index number 1 (to select the second element) like this:

```javascript
const selector = {
    "elementProperties": {
        "viewName": "sap.ui.demo.cart.view.Home",
        "metadata": "sap.m.StandardListItem"
    }
};
const index = 1;
await ui5.element.getDisplayed(selector, index);
```
Caution: You cannot do it in other any other way, this is not a javascript function which we evaluate, its a standard pattern we are parsing. ***So dont do renaming or add index directly in the function, the following code will fail:***
```javascript
const myOwnSelectorName = {
    "elementProperties": {
        "viewName": "sap.ui.demo.cart.view.Home",
        "metadata": "sap.m.StandardListItem"
    }
};

await ui5.element.getDisplayed(selector, 1);
```
#### Why my non-ui5 tests doesn't work?
You may face execution issue when you are trying (after recording all steps) to execute your non-ui5 tests. Well, maybe you forgot to set the ignoreSynchronisation flag to false.

```
describe("01_myFirstScript - this is my first script", function () {
  beforeEach(async function() {
        browser.ignoreSynchronization = true;
      });
      
      afterEach(async function() {
        browser.ignoreSynchronization = false;
      });
```

#### Does Non-UI5 Qmate spotlight supports index
Currently indexes are supported only for UI5 Spotlight. For non-ui5 you can use index in the execution but not in the Spotlight.

#### Why the execution of my qmate selector failed in Qmate Spotlight?
Well many reasons, depending on the execution message. Here are some common cases:

***-*** Message "Failed" appeared. No element was found. You will also see "Total number of elements found (without index):0". You propably need to adjust the selector so an element can be found.

***-*** Message "Action failed!" appeared. In this case an element found but you chose an action that cant be execute. Example: You are trying to enter text into a button.

***-*** Message "Failed! Parsing issue with selector" appeared. Propably some comma ist missing somewhere or some closing bracket, or missing upper (") commas.

***-*** Message "Failed! Index should be a non-negative integer number" or "Failed! Index should be an integer number" appeared. You defined a negative or not a number type index value.

***-*** Message "Failed! Something went wrong with the parsing of the information" appeared. That means that you changed something that hinters the execution of the script. Please read above question "How can I adjust content of the generated step?".

#### Why the selected action doesnt work in the Browser?
As mentioned in the Limitation chapter, there are issues sometimes executing an action in browser because the browser execution is not the same as the webdriver execution with Qmate. We are working on making the action execution as similiar as possible with the real test execution (we are aware of issues and we are working on it). Still dont be discourage if an action is not executed in browser, doesnt mean necessarily is not executed in the test.

#### Why so many alternatives in Qmate Non-UI5 spotlight?
For non-ui5 based applications, there are many ways to find the most efficient selector, depending on your application, your level of experience and your skills. Generally we are trying to provide you the easiest and more understanadable alternatives in the beginning of the list, still, you would need to choose on your own, what is the best solution for yourself. In UI5 spotlight, things are a little easier, since the locator rules are better defined, and since the UI5 framework provides many out-of-the-box features that makes much easier to locate an element, consequently makes it easier to create more robust selectors. In both cases you still would need to use your own experience and extend and adjust the selectors, we are "trying" to provide you very robust selector, but ofcourse we dont guarantee you that.


## Goal of Spotlight
Ofcourse we believe that the tests should be writen from the developers and quality automation experts as part of your agile development process, and you should understand it, and make yourself comfortable writting tests before you push your changes. But ofcourse we understand, it doesnt hurt having some help, on creating an initial robust and reliable selector, which can save you alot of time from the test creation.

We generate robust, clean and reliable selectors for you, not so you stop thinking, but for you to learn faster how to create a qmate selector, create reliable tests faster, so you find product issues even easier. Make sure you understand what Spotlight is generating for you, otherwise just copy-pasting selectors may lead to test maintenance hell. 
In Qmate we promote Page-Objects and reusability (sharable reuasable BO modules & tests). With Qmate Spotlight, we are trying to make it easier for you to create reusable page objects, by running in browser directly, making the test maintainance even easier. 


## Limitations & known-issues
***-*** Currently the Non-ui5 spotlight doesnt work in UYT, there is an issue with way SAP generates the iframe together with DevTools, see issue [here](https://bugs.chromium.org/p/chromium/issues/detail?id=1078816).  ***In progress***.

***-*** Action may not always work, because these are browser action and not selenium based action (which you can trigger only through the execution). But if an action doesnt work in Qmate Spotlight doesnt mean necessarily it will not work in execution. The main intent is to test the selector,  ***actions execution still work in progress***.

***-*** Currently the Non-ui5 spotlight doesnt not support indexes. We are working to provide you the possibility.  ***In progress***
